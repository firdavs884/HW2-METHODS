﻿/* Реализовать метод проверки логина и пароля. На вход метода подается логин и пароль.
 * На выходе истина, если прошел авторизацию, и ложь, если не прошел (Логин: root, Password: GeekBrains).
 * Используя метод проверки логина и пароля, написать программу: пользователь вводит логин и пароль,
 * программа пропускает его дальше или не пропускает. С помощью цикла do while ограничить ввод пароля тремя попытками. */
 using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2_HW2_exercise4
{
    public class HW2EX4
    {
        public static void Pause(string message)
        {
            Console.WriteLine(message);
            Console.ReadLine();
        }
        static void Main()
        {
            string id = "root";
            string attempts;
            string pass = "GeekBrains";
            int n = 0;
            do
            {
                Console.WriteLine("Введите логин:");
                attempts = Console.ReadLine();
                Console.WriteLine("Введите пароль:");
                attempts = Console.ReadLine();

                if (attempts == pass)
                {
                    Console.WriteLine("Правильно");
                    break;
                }
                else
                {
                    Console.WriteLine("Ошибка");
                    n++;
                }
            } while (n<=2);


            /* for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Введите логин");
                string id = Console.ReadLine();
                Console.WriteLine("Введите пароль");
                string pass = Console.ReadLine();
                if (id != "root" || pass != "GeekBrains")
                    attempts++;
                else
                    break;

            }

            if (attempts > 2)
                Console.WriteLine("Правильно");
            else
                Console.WriteLine("Ошибка"); */
            Pause("Press any key");
        }
    }
}

