﻿//Написать метод подсчета количества цифр числа.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lesson2_HW2_exercise1
{
    public class HW

    {
        public static void Pause()
        {
            Console.ReadKey();
        }
        public static void Pause(string message)
        {
            Console.WriteLine(message);
            Console.ReadKey();
        }

       public static void Main()
        
        {
            Console.Write("Введите первую цифру = ");
            int x = int.Parse(Console.ReadLine());

            Console.Write("Введите вторую чифру = ");
            int y = int.Parse(Console.ReadLine());

            Console.Write("Введите третюю цифру = ");
            int z = int.Parse(Console.ReadLine());

            int min = Math.Min(x, Math.Min(y, z));

            Console.WriteLine(min);
                         
        }  
        
    
    }
}