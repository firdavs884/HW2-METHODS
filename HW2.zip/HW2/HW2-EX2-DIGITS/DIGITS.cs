﻿//Написать метод подсчета количества цифр числа.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2_HW2_exercise2
{
    public class HW2EX2
    {
        public static void Pause(string message)
        {
            Console.WriteLine(message);
            Console.ReadLine();
        }
        static void Main()
        {
            Console.WriteLine("Введите число");
            int a = Int32.Parse(Console.ReadLine());
            int b = a;
            int s = 0, r = 0;
            while (a != 0)
            {
                r = a % 10;
                s = s + r;
                a = a / 10;
            }
            Console.WriteLine("Ответ={1}", b, s);

            Pause("Press any key");
        }
    }
}

