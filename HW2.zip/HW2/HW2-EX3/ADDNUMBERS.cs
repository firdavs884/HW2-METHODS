﻿//С клавиатуры вводятся числа, пока не будет введен 0. Подсчитать сумму всех нечётных положительных чисел.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2_HW2_exercise3
{
    public class HW2EX3
    {
        public static void Pause(string message)
        {
            Console.WriteLine(message);
            Console.ReadLine();
        }
        static void Main()
        {

            for (int i = 0; i < 100; i += 2)
            {
                Console.WriteLine(i);
            }



        Pause("Press any key");
        }
    }
      
    } 